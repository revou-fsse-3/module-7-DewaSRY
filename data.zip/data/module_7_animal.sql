CREATE DATABASE  IF NOT EXISTS `module_7` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `module_7`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: module_7
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `animal`
--

DROP TABLE IF EXISTS `animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `animal` (
  `animal_id` varchar(36) NOT NULL,
  `name` varchar(50) NOT NULL,
  `species_id` int NOT NULL,
  `gender_id` int NOT NULL,
  `age` int NOT NULL,
  PRIMARY KEY (`animal_id`),
  KEY `gender_id` (`gender_id`),
  KEY `species_id` (`species_id`),
  CONSTRAINT `animal_ibfk_1` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`gender_id`),
  CONSTRAINT `animal_ibfk_2` FOREIGN KEY (`species_id`) REFERENCES `species` (`species_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `animal`
--

LOCK TABLES `animal` WRITE;
/*!40000 ALTER TABLE `animal` DISABLE KEYS */;
INSERT INTO `animal` VALUES ('016c1380-8958-4f6e-907a-d84a35b33105','Lion',2,2,70),('0361651a-2ed7-444b-9a59-df313dfbab99','Lion',2,1,9),('0bfebd06-5452-4a56-bb01-2fdb0cd89d4d','Lion',2,1,9),('0fb728fc-97f4-492a-99b2-8bc86a451310','Lion',2,1,9),('1dacf210-f2cd-4cc0-9c08-529c31063594','Lion',2,1,9),('20bc762d-f0fc-4226-9a08-e1588a77ad50','Lion',2,1,9),('26ebc1a9-4ac2-4d42-8d61-44dfb096b5c5','Lion',2,1,9),('33738634-e292-4600-be04-8e199e240209','cat',2,1,9),('3ba532a4-4e92-4baf-989c-d149a9c682b2','Lion',2,1,9),('408997a0-8025-422a-aa36-b5f25160b361','Lion',2,1,9),('469245c6-1209-4832-8e31-4d35b71e6119','Lion',2,1,9),('4729211f-e74a-4fb6-9bd4-ea76f8285fb0','Lion',2,1,9),('4a88fcee-976b-4e5a-90a3-08b270affc26','Lion',2,1,9),('4f6195bb-ca42-40e0-9684-5cdcf3b4e799','Lion',2,1,9),('56551dcd-1265-4617-895e-8b1b03a67434','Lion',2,1,9),('570822ce-bfbd-4540-876f-708f38920cb7','Lion',2,1,9),('57ba23b3-01f7-476b-acee-290739f1da65','Lion',2,1,9),('598ac18b-9d11-4b07-9d7b-1b278613f611','Lion',2,1,9),('5bceaa7f-147e-4fc6-8029-59c533a43783','Lion',2,1,9),('5c6cdb75-1121-4e5d-9b71-cb32dc3578d6','Lion',2,1,9),('6367f021-21e3-4479-a1fe-8e17412ae914','Lion',2,1,9),('6995de7b-cfb9-437b-8d7e-b28215557fe6','Lion',2,1,9),('6f709372-5e6b-4b53-a758-cab55fd4a41c','Lion',2,1,9),('6fff0f1e-19ec-4693-9d6b-45ee65e6ec23','Lion',2,1,9),('7401fa13-cbd1-4196-89eb-c6efe394c51e','Lion',2,1,9),('7795ed43-89cc-4e44-960b-d6ac13474248','Lion',2,1,9),('781d022f-100f-4b6f-8573-cdd55bb67eab','Lion',2,1,9),('803f8440-dbab-46cd-b753-6ce4c09cf72a','Lion',2,1,9),('85898016-5dd9-427c-b965-372452cf0166','Lion',2,1,9),('88b61513-6fa8-4470-9816-bc55f4278ac7','Lion',2,1,9),('96030b27-e9ce-4a2f-a2dc-0db792c48cdb','Lion',2,1,9),('a25c781b-ab5a-4db2-8b66-e8c0fe278338','Lion',2,1,9),('a937c6b6-fd36-47e4-b0fd-6703cb59dc57','Lion',2,1,9),('ab86424c-878a-4a00-836a-58b2f78fc685','Lion',2,1,9),('ad846709-48e2-4ff2-802b-5b24a62a441e','Lion',2,1,9),('b126de2a-88aa-42e6-8265-00be291fdc34','Lion',2,1,9),('b504f5af-05ff-4086-bfe9-c6186280f485','Lion',2,1,9),('b65cd1aa-32a4-4ff9-bd55-d49e4c70b90d','Lion',2,1,9),('b6dfc130-b971-43a4-83ca-19e3f6972a05','Lion',2,1,9),('bbe17729-1066-4884-83a2-d2b1c16464bd','Lion',2,1,9),('c0e96c21-fc28-4ca2-9a15-0696d11bcbe9','Lion',2,1,9),('c9a75e87-27d9-4d05-ab1d-25ae206911be','Lion',2,1,9),('ca314ef1-82ca-4564-9717-b45db836b680','Lion',2,1,9),('cdaadcbc-3d2c-4164-80c6-f208781b66d4','Lion',2,1,9),('d02adb47-0fb1-4ef6-b52f-91f28880dc18','Lion',2,1,9),('d108594d-74fa-42b1-aca6-e45f31876bec','Lion',2,1,9),('d954b0a9-3bdb-4649-88c4-1d26be5a9958','Lion',2,1,9),('dd5b1055-68f8-48dc-a99c-e96398674675','Lion',2,1,9),('dd819f7b-4ecd-4e35-a29a-498c646d813b','Lion',2,1,9),('ddce9464-4408-4914-a862-c58aa462aab9','some anima',2,2,9),('ddfc5b59-7797-464e-b1b1-a41c4b9ab675','Lion',2,1,9),('e0c3d69d-bcc7-4c63-8c8b-9b7d385cf13f','Lion',2,1,9),('e68dc2e7-1b87-4c83-9385-890b30eefe06','Lion',2,1,9),('eb03dc29-a016-4aba-bd01-5b9b88ef0920','Lion',2,1,9),('ee35d487-15e7-4f57-975b-12a489f508fb','Lion',2,1,9),('f17a1f7d-d89c-4f82-a0de-87c733d71bed','Lion',2,1,9),('f660f759-a8d8-4245-801e-43c9d2cbace7','Lion',2,1,9),('f67ed6bb-a7d1-4719-967a-99b18bc04b4d','Lion',2,1,9),('f779ccb1-7072-4e7c-9624-af305e2a1b1e','Lion',2,1,9),('fab87816-6544-429e-8808-6573eda125a6','Lion',2,1,9),('fae78397-fd32-4526-8c23-c080b2e90188','Lion',2,1,9),('feacdcb0-cfe7-4cf0-9320-3a6ce7101c7c','Lion',2,1,9);
/*!40000 ALTER TABLE `animal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-08 14:30:21
